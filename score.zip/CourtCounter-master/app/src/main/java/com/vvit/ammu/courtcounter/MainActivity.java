package com.vvit.ammu.courtcounter;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    int A=0;
    int B=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }
    protected void threepoints(View view)
    {
        A=A+3;
        TextView tv=(TextView)findViewById(R.id.id_score_teamA);
        tv.setText(" "+A);
    }
    protected void bthreepoints(View view)
    {
        B=B+3;
        TextView tv=(TextView)findViewById(R.id.id_score_teamB);
        tv.setText(" "+B);
    }
    protected void twopoints(View view)
    {
        A=A+2;
        TextView tv=(TextView)findViewById(R.id.id_score_teamA);
        tv.setText(" "+A);
    }
    protected void btwopoints(View view)
    {
        B=B+2;
        TextView t=(TextView)findViewById(R.id.id_score_teamB);
        t.setText(" "+B);
    }
    protected void onReset(View view)
    {
        A=0;
        B=0;
        TextView t=(TextView)findViewById(R.id.id_score_teamB);
        t.setText(" "+B);
        TextView tv=(TextView)findViewById(R.id.id_score_teamA);
        tv.setText(" "+A);
    }
    protected void onfreethrow(View view)
    {
        Toast.makeText(MainActivity.this, "Free Throw!",
                Toast.LENGTH_LONG).show();
    }
}
